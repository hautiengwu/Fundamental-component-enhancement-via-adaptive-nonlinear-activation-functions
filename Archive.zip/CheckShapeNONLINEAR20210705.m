matdatafolder = '/Volumes/MY PASSPORT/ZIO July 2018 mat' ;
ggg = dir([matdatafolder,'/*.mat']) ;
idx = [] ;
for jj = 1: length(ggg)
    if length(strfind(ggg(jj).name(1:2), '._'))
        idx = [idx jj] ;
    end
end
ggg(idx) = [] ;






NO = 50000 ;
IDX = 1 ;

scrsz = get(0,'ScreenSize');
h0 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]) ;

fs = 512 ;
T = 8 ;
t = [1: fs*T] / fs ;
xi = fs * [1: length(t)/2] / length(t) ;
idx1 = find(xi == 1) ;

STRENGTH = nan(NO, 6) ;
STRENGTHl1 = nan(NO, 6) ;
STRENGTHl5 = nan(NO, 6) ;

h1 = waitbar(0) ;


for cNO = 1:3
    
    
    filename = ggg(cNO*300).name(1:end-4) ;
    load([matdatafolder,'/',filename,'.mat']) ;
    x = x(1e4+1: 1e4 + 200*14) ;
    trend = medfilt1(x, 200*2) ;
    trend = smooth(trend, 200*3, 'loess') ;
    x = x-trend ;
    x = x(200*2+1: 200*2+200*10) ;
    R = HRCFTG(x, 200) ;
    L = min(diff(R)) ;
    z = x(R(2)-ceil(L*0.2)+1: R(2)+ceil(L*0.8)) ;
    z = resample(z, 512, length(z)) ;
    zhat = fft(z) ;
    zhat(102:412) = 0 ;
    z = ifft(zhat);
    
    
    
    for jj = 1: NO
        
        waitbar(jj/NO, h1) ;
        
        if jj > 1
            A = randn(100,1)/10 + 1 ;
            phi = (rand(100,1)-0.5) /5 ; 
            J = exp(i*2*pi*phi) ;
            zhat(2:101) = zhat(2:101) .* A .* J ;
            zhat(512:-1:413) = zhat(512:-1:413) .* A .* conj(J) ;            
        end
        
        zhat(2) = 0 ; zhat(end) = 0 ;
        z = ifft(zhat) ;
        x = repmat(z, T, 1) ;
        
        if jj == 1 
            figure ; 
            xhat = abs(fft(x)) ;
            subplot(211) ; plot(t, x, 'k') ; axis tight ; xlabel('Time (sec)') ;
            subplot(212) ; plot(xi, xhat(2:length(xi)+1), 'k') ; 
            axis([0 60 -inf inf]) ; xlabel('Freq (Hz)') ;   
            export_fig(['sig_spec_' num2str(cNO)],'-transparent','-m2');
            close
        end
        
        
        x1 = abs(x) ;
        xhat = abs(fft(x1)) .^ 2 ;
        STRENGTH(IDX, 1) = sum(xhat(idx1-1:idx1+1)) ./ sum(xhat(1:end/2)) ;
        
        tmp = zeros(fs/2 - 2, 1) ;
        for qqq = 1: fs/2-2
            idxk = find(xi == qqq) ;
            tmp(qqq) = sum(xhat(idxk-1:idxk+1)) ;
        end
        STRENGTHl1(IDX, 1) = sum(tmp(1)) ./ sum(tmp(2:end)) ;
        STRENGTHl5(IDX, 1) = sum(tmp(1:5)) ./ sum(tmp(6:end)) ;
        
        
        
        % RELU
        x2 = x ; x2(find(x2<0)) = 0 ;
        xhat = abs(fft(x2)) .^ 2 ;
        STRENGTH(IDX, 2) = sum(xhat(idx1-1:idx1+1)) ./ sum(xhat(1:end/2)) ;
        
        tmp = zeros(fs/2 - 2, 1) ;
        for qqq = 1: fs/2-2
            idxk = find(xi == qqq) ;
            tmp(qqq) = sum(xhat(idxk-1:idxk+1)) ;
        end
        STRENGTHl1(IDX, 2) = sum(tmp(1)) ./ sum(tmp(2:end)) ;
        STRENGTHl5(IDX, 2) = sum(tmp(1:5)) ./ sum(tmp(6:end)) ;
        
        
        %
        x3 = 0.95 * x ./ max(abs(x)) ;
        x3 = 1 ./ (1 - x3) ;
        xhat = abs(fft(x3)) .^ 2 ;
        STRENGTH(IDX, 3) = sum(xhat(idx1-1:idx1+1)) ./ sum(xhat(1:end/2)) ;
        
        tmp = zeros(fs/2 - 2, 1) ;
        for qqq = 1: fs/2-2
            idxk = find(xi == qqq) ;
            tmp(qqq) = sum(xhat(idxk-1:idxk+1)) ;
        end
        STRENGTHl1(IDX, 3) = sum(tmp(1)) ./ sum(tmp(2:end)) ;
        STRENGTHl5(IDX, 3) = sum(tmp(1:5)) ./ sum(tmp(6:end)) ;
        
        
        %
        x4 = 0.99 * x ./ max(abs(x)) ;
        x4 = 1 ./ (1 - abs(x4)) ;
        xhat = abs(fft(x4)) .^ 2 ;
        STRENGTH(IDX, 4) = sum(xhat(idx1-1:idx1+1)) ./ sum(xhat(1:end/2)) ;
        
        tmp = zeros(fs/2 - 2, 1) ;
        for qqq = 1: fs/2-2
            idxk = find(xi == qqq) ;
            tmp(qqq) = sum(xhat(idxk-1:idxk+1)) ;
        end
        STRENGTHl1(IDX, 4) = sum(tmp(1)) ./ sum(tmp(2:end)) ;
        STRENGTHl5(IDX, 4) = sum(tmp(1:5)) ./ sum(tmp(6:end)) ;
        
        
        %
        x5 = 0.995 * x ./ max(abs(x)) ;
        x5 = 1 ./ (1 - x5) ;
        xhat = abs(fft(x5)) .^ 2 ;
        STRENGTH(IDX, 5) = sum(xhat(idx1-1:idx1+1)) ./ sum(xhat(1:end/2)) ;
        
        tmp = zeros(fs/2 - 2, 1) ;
        for qqq = 1: fs/2-2
            idxk = find(xi == qqq) ;
            tmp(qqq) = sum(xhat(idxk-1:idxk+1)) ;
        end
        STRENGTHl1(IDX, 5) = sum(tmp(1)) ./ sum(tmp(2:end)) ;
        STRENGTHl5(IDX, 5) = sum(tmp(1:5)) ./ sum(tmp(6:end)) ;
        
        
        %
        x6 = 0.999 * x ./ max(abs(x)) ;
        x6 = 1 ./ (1 - abs(x6)) ;
        xhat = abs(fft(x6)) .^ 2 ;
        STRENGTH(IDX, 6) = sum(xhat(idx1-1:idx1+1)) ./ sum(xhat(1:end/2)) ;
        
        tmp = zeros(fs/2 - 2, 1) ;
        for qqq = 1: fs/2-2
            idxk = find(xi == qqq) ;
            tmp(qqq) = sum(xhat(idxk-1:idxk+1)) ;
        end
        STRENGTHl1(IDX, 6) = sum(tmp(1)) ./ sum(tmp(2:end)) ;
        STRENGTHl5(IDX, 6) = sum(tmp(1:5)) ./ sum(tmp(6:end)) ;
        
        
        
        
        %{
        x7 = 0.999 * x ./ max(abs(x)) ;
        x7 = 1 ./ (1 - x7) ;
        xhat = abs(fft(x7)) .^ 2 ;
        STRENGTH(IDX, 7) = sum(xhat(idx1-1:idx1+1)) ./ sum(xhat(1:end/2)) ;
        
        tmp = zeros(fs/2 - 2, 1) ;
        for qqq = 1: fs/2-2
            idxk = find(xi == qqq) ;
            tmp(qqq) = sum(xhat(idxk-1:idxk+1)) ;
        end
        STRENGTHl1(IDX, 7) = sum(tmp(1)) ./ sum(tmp(2:end)) ;
        STRENGTHl5(IDX, 7) = sum(tmp(1:5)) ./ sum(tmp(6:end)) ;
        
        
        %
        x8 = 0.999 * x ./ max(abs(x)) ;
        x8 = x8.^10 ./ (1 - abs(x8)) ;
        xhat = abs(fft(x8)) .^ 2 ;
        STRENGTH(IDX, 8) = sum(xhat(idx1-1:idx1+1)) ./ sum(xhat(1:end/2)) ;
        
        tmp = zeros(fs/2 - 2, 1) ;
        for qqq = 1: fs/2-2
            idxk = find(xi == qqq) ;
            tmp(qqq) = sum(xhat(idxk-1:idxk+1)) ;
        end
        STRENGTHl1(IDX, 8) = sum(tmp(1)) ./ sum(tmp(2:end)) ;
        STRENGTHl5(IDX, 8) = sum(tmp(1:5)) ./ sum(tmp(6:end)) ;
        
        %}
        
        
        IDX = IDX + 1 ;
        
    end
    
    
    %%
    idxQ = find(~isnan(sum(STRENGTH,2))) ;
    ITEM = {'abs', 'RELU', 'x^2', 'log|x|', 'x^{50}', '1/(1-x)'} ;
    ITEM = {'abs', 'RELU', '\epsilon=0.95', '\epsilon=0.99', '\epsilon=0.995',...
        '\epsilon=0.999'} ;
    
    tmp = log(STRENGTH(idxQ, :)) ;
    mmm = floor(min(tmp(:))) ;
    
    figure(h0) ;
    for jj = 1: 6
        subplot(3,2,jj) ;
        hist(log(STRENGTH(idxQ, jj)), 200) ;
        ylabel(ITEM{jj}) ; axis([mmm 0 -inf inf]) ;
    end
    
    export_fig(['shapeNONLINEAR2c_',num2str(cNO)], '-transparent','-m2') ;
    
    %
    tmp = log(STRENGTHl1(idxQ, :)) ;
    mmm = floor(min(tmp(:))) ;
    
    figure(h0) ;
    for jj = 1: 6
        subplot(3,2,jj) ;
        hist(log(STRENGTHl1(idxQ, jj)), 200) ;
        ylabel(ITEM{jj}) ; 
        axis([mmm 0 -inf inf]) ;
    end
    
    export_fig(['shapeNONLINEAR2cL1_',num2str(cNO)], '-transparent','-m2') ;
    
    %
    tmp = log(STRENGTHl5(idxQ, :)) ;
    mmm = floor(min(tmp(:))) ;
    
    figure(h0) ;
    for jj = 1: 6
        subplot(3,2,jj) ;
        hist(log(STRENGTHl5(idxQ, jj)), 200) ;
        ylabel(ITEM{jj}) ; axis([mmm 0 -inf inf]) ;
    end
    
    export_fig(['shapeNONLINEAR2cL5_',num2str(cNO)], '-transparent','-m2') ;
    
    
    pause(1)
end