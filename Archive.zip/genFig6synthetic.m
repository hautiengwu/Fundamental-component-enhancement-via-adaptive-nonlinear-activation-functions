close all; clear


scrsz = get(0,'ScreenSize');


NO = 1e5 ;
IDX = 1 ;



fs = 512 ;
T = 8 ;
t = [1: fs*T] / fs ;
xi = fs * [1: length(t)/2] / length(t) ;
idx1 = find(xi == 1) ;



STRENGTH = zeros(NO, 4) ;


h1 = waitbar(0) ;


for jj = 1: NO
    
        waitbar(jj/NO, h1) ;

    K = ceil(rand(1) * 96) + 4 ;
            
    cidx = min(250, ceil(abs(randn(K,1))*100) + 1) ;
    
    if gcd(cidx(5), gcd(cidx(4), gcd(cidx(1), gcd(cidx(2), cidx(3))))) == 1
        
        
        am = max(rand(length(cidx),1), 1e-3) ; 
        phi = rand(length(cidx),1) * 2*pi ;
        
        xx = zeros(1,fs*T) ;
        
        for qq = 1: length(am)
            xx = xx + am(qq) * cos(2*pi*cidx(qq)*t + phi(qq)) ;
        end
        
        xhat = fft(xx) ;
        if abs(xhat(2)) ./ norm(xx) > 1e-6
            pause
        end
        
        
        % abs
        x1 = abs(xx) ;
        xhat1 = abs(fft(x1)) .^ 2 ;
        STRENGTH(IDX, 1) = sum(xhat1(idx1+1)) ./ sum(xhat1(2:end/2)) ;
        
        % RELU
        x2 = xx ; x2(find(x2<0)) = 0 ;
        xhat2 = abs(fft(x2)) .^ 2 ;
        STRENGTH(IDX, 2) = sum(xhat2(idx1+1)) ./ sum(xhat2(2:end/2)) ;
        
        %
        x3 = 0.8 * xx ./ max(abs(xx)) ;
        x3 = 1 ./ (1 - abs(x3)) ;
        xhat3 = abs(fft(x3)) .^ 2 ;
        STRENGTH(IDX, 3) = sum(xhat3(idx1+1)) ./ sum(xhat3(2:end/2)) ;
        
        %
        x4 = 0.9 * xx ./ max(abs(xx)) ;
        x4 = 1 ./ (1 - abs(x4)) ;
        xhat4 = abs(fft(x4)) .^ 2 ;
        STRENGTH(IDX, 4) = sum(xhat4(idx1+1)) ./ sum(xhat4(2:end/2)) ;
        
        %
        x5 = 0.95 * xx ./ max(abs(xx)) ;
        x5 = 1 ./ (1 - abs(x5)) ;
        xhat5 = abs(fft(x5)) .^ 2 ;
        STRENGTH(IDX, 5) = sum(xhat5(idx1+1)) ./ sum(xhat5(2:end/2)) ;
        
        IDX = IDX + 1 ;
        
    end
end




disp(IDX)





%%
idxQ = find(~isnan(sum(log(STRENGTH),2))) ;
ITEM = {'abs', 'RELU', '\epsilon=0.2', '\epsilon=0.1', '\epsilon=0.05'} ;

tmp = log(STRENGTH(idxQ, :)) ;
mmm = floor(min(tmp(:))) ;


% provide the ratio improvement. remember to comment out "remove the fundamental
% component"
h2 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)/4]) ;

for jj = 1: 5
    subplot(1,5,jj) ;
    [a,b] = hist(log(STRENGTH(idxQ, jj)), 200) ;
    bar(b,a/sum(a), 'k')
    ylabel(ITEM{jj}) ; axis([-20 0 0 0.12]) ;
    xlabel('log(energy ratio)') ;
    set(gca,'fontsize', 16) ;
    disp([num2str(round(100000*median(STRENGTH(idxQ, jj)))/1000) ' ' ...
        num2str(round(100000*mad(STRENGTH(idxQ, jj)))/1000)]) ;
end


export_fig(['Fig6synthetic'], '-transparent','-m3') ;


