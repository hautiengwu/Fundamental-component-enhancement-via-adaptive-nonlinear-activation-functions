clear all ; close all ;


addpath('/Users/hautiengwu/Dropbox/___course 20191219/NCTS2021 Spring Geometric Learning/code deshape') ;

scrsz = get(0,'ScreenSize');



%% load signals



fs0 = 16000 ;
fs = 1000 ;

genFig3Fig4Fig9 = 1 ;


%% setup parameters for de-shape

basicTF.win = fs * 10 ;
basicTF.hop = fs/4 ;
basicTF.fs = fs ;
basicTF.fr = 0.02 ;
basicTF.feat = 'SST11';
advTF.num_tap = 1;%num_tap(cc);
advTF.win_type = 'Gauss'; %{'Gaussian','Thomson','multipeak','SWCE'}; %}
advTF.Smo = 1;
advTF.Rej = 0;
advTF.ths = 1E-9;
advTF.HighFreq = 100/fs ;
advTF.LowFreq = 0.1/fs ;
advTF.lpc = 0;
cepR.g = 0.1; % g(cc);%0.06;
cepR.Tc=0;
P.num_s = 1;
P.num_c = 1;


figure('Position',[1 scrsz(4) scrsz(3)*2/3 scrsz(4)])


Rfs = 0.2 ;

%%
ggg = dir('shiraz-university-fetal-heart-sounds-database-1.0.1/m*.wav');


% for figure 1 & 5, use jj=11
% for figure 6, use jj=78
for jj = 11 %length(ggg)
    
    fprintf([num2str(jj),'/',num2str(length(ggg)),'\n']) ;
    
    x = audioread(['shiraz-university-fetal-heart-sounds-database-1.0.1/' ggg(jj).name]);
    
    if max(abs(x(:,1)-x(:,2))) > 1e-3
        keyboard
    end
    
    x = x(:,1) ;
    y = resample(x, fs, fs0) ;
    z1 = resample(abs(x), fs, fs0) ;
    
    if ~exist(['PCGTFR/' ggg(jj).name(1:end-4),'.mat'])
        
        [tfr, ceps, iceps, dstfr, dstfrsq, tfrsq, tfrtic] = deshape(y-mean(y), basicTF, advTF, cepR, P);
        
        z1 = resample(abs(x), fs, fs0) ;
        [tfrn1, ceps, iceps, dstfrn1, dstfrsqn1, tfrsqn1, tfrtic] = deshape(z1-mean(z1), basicTF, advTF, cepR, P);
        
        
        z2 = 1 ./ (1 - 0.9 * abs(x)./max(abs(x))) ;
        z2 = resample(z2, fs, fs0) ;
        [tfrn2, ceps, iceps, dstfrn2, dstfrsqn2, tfrsqn2, tfrtic] = deshape(z2-mean(z2), basicTF, advTF, cepR, P);
        
        z3 = x ; z3(find(x<0)) = 0 ;
        z3 = resample(z3, fs, fs0) ;
        [tfrn3, ceps, iceps, dstfrn3, dstfrsqn3, tfrsqn3, tfrtic] = deshape(z3-mean(z3), basicTF, advTF, cepR, P);
        
        
        
        save([ggg(jj).name(1:end-4),'.mat'], 'tfr','dstfrsq','dstfr','tfrn1','dstfrsqn1','dstfrn1',...
            'tfrn2','dstfrsqn2','dstfrn2','tfrn3','dstfrsqn3','dstfrn3','tfrtic') ;
        
    else
        load(['PCGTFR/' ggg(jj).name(1:end-4),'.mat']) ;
    end
    
    
    tmp = find(tfrtic*fs < 2.5 & tfrtic*fs > 0.5) ;
    [c] = CurveExt_M(abs(dstfrsqn1(tmp, :))', .1);
    c = c + tmp(1) - 1 ;
    
    RLen = ceil(Rfs ./ ((tfrtic(2)-tfrtic(1)) * fs)) ;
    tmp1 = 0 ; tmp2 = 0 ;
    for ll = 2: size(tfr, 2)
        rang = max(1, c(ll)-RLen): c(ll)+RLen ;
        tmp1 = tmp1 + sum(tfr(rang, ll)) ; tmp2 = tmp2 + sum(tfr(2:end, ll)) ;
    end
    ERg0(jj) = tmp1 ./ tmp2 ;
    
    tmp1 = 0 ; tmp2 = 0 ;
    for ll = 2: size(tfr, 2)
        rang = max(1, c(ll)-RLen): c(ll)+RLen ;
        tmp1 = tmp1 + sum(tfrn1(rang, ll)) ; tmp2 = tmp2 + sum(tfrn1(2:end, ll)) ;
    end
    ERg1(jj) = tmp1 ./ tmp2 ;
    
    tmp1 = 0 ; tmp2 = 0 ;
    for ll = 2: size(tfr, 2)
        rang = max(1, c(ll)-RLen): c(ll)+RLen ;
        tmp1 = tmp1 + sum(tfrn2(rang, ll)) ; tmp2 = tmp2 + sum(tfrn2(2:end, ll)) ;
    end
    ERg2(jj) = tmp1 ./ tmp2 ;
    
    tmp1 = 0 ; tmp2 = 0 ;
    for ll = 2: size(tfr, 2)
        rang = max(1, c(ll)-RLen): c(ll)+RLen ;
        tmp1 = tmp1 + sum(tfrn3(rang, ll)) ; tmp2 = tmp2 + sum(tfrn3(2:end, ll)) ;
    end
    ERg3(jj) = tmp1 ./ tmp2 ;
    
    
    % the new sampling periods associated with the hop
    DeltaT = basicTF.hop/basicTF.fs;
    
    
    % plot all results
    
    if genFig3Fig4Fig9
        
        figure('Position',[1 scrsz(4) scrsz(3)/2 scrsz(4)/4])
        
        subplot(1,2,1) ;
        imageSQ(0:DeltaT:DeltaT*(size(dstfrn1,2)-1), tfrtic(10:end)*basicTF.fs, tfrn3(10:end,2:end), 0.995); axis xy; colormap(1-gray);
        xlabel('time (sec)'); ylabel('frequency (Hz)'); %title('ds-spectrogram')
        axis([-inf inf -inf 5]) ; set(gca,'fontsize', 24) ;
        
        subplot(1,2,2) ;
        imageSQ(0:DeltaT:DeltaT*(size(dstfrn1,2)-1), tfrtic(10:end)*basicTF.fs, tfrn2(10:end,2:end), 0.995); axis xy; colormap(1-gray);
        xlabel('time (sec)'); ylabel('frequency (Hz)'); %title('ds-spectrogram')
        axis([-inf inf -inf 5]) ; set(gca,'fontsize', 24) ;
        
        export_fig(['Fig9PCG'], '-transparent','-m3') ;
        
        
        
        
        
        figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)/2])
        
        % plot all results
        subplot(1,2,1) ;
        plot([1:length(x)]/fs0, x, 'k', 'linewidth', 1) ; 
        axis tight ;  
        ylabel('PCG (a.u.)'); set(gca,'fontsize', 24) ;
        axis([11.4 12.6 -1 1]) ; xlabel('time (sec)');
        
        %subplot(2,2,3) ;
        %imageSQ(0:DeltaT:DeltaT*(size(dstfrn1,2)-1), tfrtic*basicTF.fs, tfr(:,2:end), 0.995);
        %axis xy; colormap(1-gray);
        %xlabel('time (sec)'); ylabel('frequency (Hz)'); %title('ds-spectrogram')
        %axis([-inf inf -inf 50]) ; set(gca,'fontsize', 16) ;
        
        subplot(1,2,2) ;
        imageSQ(0:DeltaT:DeltaT*(size(dstfrn1,2)-1), tfrtic(10:251)*basicTF.fs, tfr(10:251,2:end), 0.995);
        axis xy; colormap(1-gray);
        xlabel('time (sec)'); ylabel('frequency (Hz)'); %title('ds-spectrogram')
        axis([-inf inf -inf 5]) ; set(gca,'fontsize', 24) ;
        
        export_fig(['Fig3PCG'], '-transparent','-m3') ;
        
        
        figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)/2])
        subplot(1,2,1) ;
        plot([1:length(x)]/fs0, abs(x), 'k', 'linewidth', 1) ; 
        axis tight ;  
        ylabel('abs(PCG) (a.u.)');  set(gca,'fontsize', 24) ;
        axis([11.4 12.6 -1 1]) ; xlabel('time (sec)');
        
        %subplot(2,2,3) ;
        %imageSQ(0:DeltaT:DeltaT*(size(dstfrn1,2)-1), tfrtic*basicTF.fs, tfrn1(:,2:end), 0.995);
        %axis xy; colormap(1-gray);
        %xlabel('time (sec)'); ylabel('frequency (Hz)'); %title('ds-spectrogram')
        %axis([-inf inf -inf 50]) ; set(gca,'fontsize', 16) ;
        
        subplot(1,2,2) ;
        imageSQ(0:DeltaT:DeltaT*(size(dstfrn1,2)-1), tfrtic(10:251)*basicTF.fs, tfrn1(10:251,2:end), 0.995);
        axis xy; colormap(1-gray);
        xlabel('time (sec)'); ylabel('frequency (Hz)'); %title('ds-spectrogram')
        axis([-inf inf -inf 5]) ; set(gca,'fontsize', 24) ;
        
        export_fig(['Fig4PCG'], '-transparent','-m3') ;
        
    else
        
        
        
        y = y(1:floor(end/2)*2) ;
        
        subplot(3,3,[1 2 3]) ;
        plot([1:length(x)]/fs0, x, 'k') ; axis tight ; axis([10 16 -inf inf]) ;
        xlabel('time (sec)'); ylabel('PCG (a.u.)') ; set(gca,'fontsize', 18) ;
        
        %subplot(3,3,3) ;
        %xi = fs * [1:length(y)/2]/length(y) ;
        %xhat = fft(y) / fs ;
        %bar(xi, abs(xhat(2:end/2+1)), 'k') ; axis([0 500 -inf inf]) ;
        %xlabel('freq (Hz)'); ylabel('PS (a.u.)') ; set(gca,'fontsize', 18) ;
        
        %subplot(3,3,6) ;
        %z = 1 ./ (1 - 0.99 * abs(y)./max(abs(y))) ;
        %xhat = fft(abs(z)) / fs ;
        %bar(xi, abs(xhat(2:end/2+1)), 'k') ; axis([0 500 -inf inf]) ;
        %xlabel('freq (Hz)'); ylabel('PS (a.u.)') ; set(gca,'fontsize', 18) ;
        
%         subplot(4,3,4) ;
%         imageSQ(0:DeltaT:DeltaT*(size(dstfrn1,2)-1), tfrtic*basicTF.fs, tfr(:,2:end), 0.995); axis xy; colormap(1-gray);
%         xlabel('time (sec)'); ylabel('freq (Hz)'); %title('ds-spectrogram')
%         axis([-inf inf 0 50]) ; set(gca,'fontsize', 16) ;
%         
%         subplot(4,3,5) ;
%         imageSQ(0:DeltaT:DeltaT*(size(dstfrn1,2)-1), tfrtic*basicTF.fs, dstfrn1(:,2:end), 0.995); axis xy; colormap(1-gray);
%         xlabel('time (sec)'); ylabel('freq (Hz)'); %title('ds-spectrogram')
%         axis([-inf inf 0 50]) ; set(gca,'fontsize', 16) ;
         
        subplot(3,3,4) ;
        imageSQ(0:DeltaT:DeltaT*(size(dstfrn1,2)-1), tfrtic(2:251)*basicTF.fs, tfr(2:251,2:end), 0.995); 
        axis xy; colormap(1-gray);
        xlabel('time (sec)'); ylabel('freq (Hz)'); %title('ds-spectrogram')
        axis([-inf inf 0 5]) ; set(gca,'fontsize', 16) ;
        
        subplot(3,3,5) ;
        imageSQ(0:DeltaT:DeltaT*(size(dstfrn1,2)-1), tfrtic(2:251)*basicTF.fs, dstfrn1(2:251,2:end), 0.995); 
        axis xy; colormap(1-gray);
        xlabel('time (sec)'); ylabel('freq (Hz)'); %title('ds-spectrogram')
        axis([-inf inf 0 5]) ; set(gca,'fontsize', 16) ;
        
        subplot(3,3,6) ;
        imageSQ(0:DeltaT:DeltaT*(size(dstfrn1,2)-1), tfrtic(2:251)*basicTF.fs, dstfrn1(2:251,2:end), 0.995); 
        axis xy; colormap(1-gray);
        xlabel('time (sec)'); ylabel('freq (Hz)'); %title('ds-spectrogram')
        hold on ; plot(0:DeltaT:DeltaT*(size(dstfrn1,2)-1), tfrtic(c)*fs, 'r', 'linewidth', 3) ;
        axis([-inf inf 0 5]) ; set(gca,'fontsize', 16) ; hold off
        
        subplot(3,3,7) ;
        imageSQ(0:DeltaT:DeltaT*(size(dstfrn1,2)-1), tfrtic(2:251)*basicTF.fs, tfrn1(2:251,2:end), 0.995); 
        axis xy; colormap(1-gray);
        hold on ; plot(0:DeltaT:DeltaT*(size(dstfrn1,2)-1), tfrtic(c+RLen)*fs, 'r--', 'linewidth', 3) ;
        plot(0:DeltaT:DeltaT*(size(dstfrn1,2)-1), tfrtic(max(1,c-RLen))*fs, 'r--', 'linewidth', 3) ;
        xlabel('time (sec)'); ylabel('freq (Hz)'); %title('abs')
        axis([-inf inf 0 5]) ; set(gca,'fontsize', 16) ;
        
        subplot(3,3,8) ;
        imageSQ(0:DeltaT:DeltaT*(size(dstfrn1,2)-1), tfrtic(2:251)*basicTF.fs, tfrn3(2:251,2:end), 0.995); 
        axis xy; colormap(1-gray);
        xlabel('time (sec)'); ylabel('frequency (Hz)'); %title('RELU')
        axis([-inf inf 0 5]) ; set(gca,'fontsize', 16) ;
        
        subplot(3,3,9) ;
        imageSQ(0:DeltaT:DeltaT*(size(dstfrn1,2)-1), tfrtic(2:251)*basicTF.fs, tfrn2(2:251,2:end), 0.995); 
        axis xy; colormap(1-gray);
        xlabel('time (sec)'); ylabel('freq (Hz)'); %title('heps')
        axis([-inf inf 0 5]) ; set(gca,'fontsize', 16) ;
        
        export_fig([ggg(jj).name(1:end-4) 'TFR'],'-transparent','-m2');
        
    end
    keyboard
    
    clear z1 z2 z3 y dstfrn3 dstfrsqn3 dstfrn2 dstfrsqn2 dstfrn1 dstfrsqn1
    
end





disp([mean(ERg0) std(ERg0)] * 100) ;
disp([mean(ERg1) std(ERg1)] * 100) ;
disp([mean(ERg2) std(ERg2)] * 100) ;
disp([mean(ERg3) std(ERg3)] * 100) ;