clear ; close all ;

matdatafolder = '/Volumes/MY PASSPORT/ZIO July 2018 mat' ;

matdatafolder = '/Users/hautiengwu/Dropbox/code/fetalECG0828/CIC2013' ;
matdatafolder2 = '/Users/hautiengwu/Dropbox/Ronen and Hautieng/NonStationaritySleep DataSet' ;

ggg = dir([matdatafolder,'/*.mat']) ;

scrsz = get(0,'ScreenSize');


REMOVEfund = 0 ;


NO = 200 ;
IDX = 1 ;



fs = 512 ;
T = 8 ;
t = [1: fs*T] / fs ;
xi = fs * [1: length(t)/2] / length(t) ;
idx1 = find(xi == 1) ;


STRENGTH = nan(NO*length(ggg) + 20*NO*10, 5) ;

h1 = waitbar(0) ;


% the 1st database

fprintf('Start the 1st database\n') ;
for cNO = 1:40
    
    waitbar(cNO/40, h1) ;
    load([matdatafolder2,'/',num2str(ceil(cNO/2)),'/ECG' num2str(1+ceil(mod(cNO/2,1))) '.mat']) ;
    if 1+ceil(mod(cNO/2,1)) == 1
        x = ECG1 ;
    else
        x = ECG2 ;
    end
    
    trend = medfilt1(x, 200*1.2) ;
    trend = smooth(trend, 200*2, 'loess') ;
    x = x-trend ;
    R = HRCFTG(x, 200) ;
    L = quantile(diff(R), 0.25) ;
    
    for jj = 1: NO*10
        
        Qidx = ceil(rand(10,1) * (length(R)-2)) + 1 ;
        % generate one ECG pattern
        z = x(R(Qidx(1))-ceil(L*0.2)+1: R(Qidx(1))+ceil(L*0.6)) ;
        for qq = 2:10
            z = z + x(R(Qidx(qq))-ceil(L*0.2)+1: R(Qidx(qq))+ceil(L*0.6)) ;
        end
        
        
        
        % remove the linear trend
        z = z + (z(1)-z(end)) * [0:length(z)-1]' ./ (length(z)-1) ;
        z = z - mean(z) ;
        
        
        
        % upsample to 512Hz
        z0 = resample(z, fs, length(z)) ;
        z0 = z0 ./ norm(z0) ;
        zhat0 = fft(z0) ;
        
        zhat = zhat0 ;
        
        
        % remove the fundamental component
        if REMOVEfund
            zhat(1) = 0 ; zhat(2) = 0 ; zhat(end) = 0 ;
        end
        z = ifft(zhat) ;
        
        % original signal
        xx0 = repmat(z0, T, 1) ;
        xhat0 = abs(fft(xx0)) .^ 2 ;
        STRENGTH(IDX, 5) = sum(xhat0(idx1+1)) ./ sum(xhat0(2:end/2)) ;
        
        
        
        
        xx = repmat(z, T, 1) ;
        
        % abs
        x1 = abs(xx) ;
        xhat1 = abs(fft(x1)) .^ 2 ;
        STRENGTH(IDX, 1) = sum(xhat1(idx1+1)) ./ sum(xhat1(2:end/2)) ;
        
        % RELU
        x2 = xx ; x2(find(x2<0)) = 0 ;
        xhat2 = abs(fft(x2)) .^ 2 ;
        STRENGTH(IDX, 2) = sum(xhat2(idx1+1)) ./ sum(xhat2(2:end/2)) ;
        
        %
        x3 = 0.95 * xx ./ max(abs(xx)) ;
        x3 = 1 ./ (1 - abs(x3)) ;
        xhat3 = abs(fft(x3)) .^ 2 ;
        STRENGTH(IDX, 3) = sum(xhat3(idx1+1)) ./ sum(xhat3(2:end/2)) ;
        
        %
        x4 = 0.99 * xx ./ max(abs(xx)) ;
        x4 = 1 ./ (1 - abs(x4)) ;
        xhat4 = abs(fft(x4)) .^ 2 ;
        STRENGTH(IDX, 4) = sum(xhat4(idx1+1)) ./ sum(xhat4(2:end/2)) ;
        
        IDX = IDX + 1 ;
        
        
    end
end




disp(IDX)


fprintf('Start the 2nd database\n') ;

% the 2nd database
for cNO = 1:length(ggg)
    
    waitbar(cNO/length(ggg), h1) ;
    
    filename = ggg(cNO).name(1:end-4) ;
    
    
    load([matdatafolder,'/',filename,'.mat']) ;
    
    for channelNO = 1: 4
        idx = find(recorddata(:,channelNO+1) > -2000) ;
        if length(idx) < length(recorddata(:, 2))
            tmp = interp1(idx, recorddata(idx, channelNO+1), [1:length(recorddata(:,2))], 'linear', 'extrap') ;
            recorddata(:, channelNO+1) = tmp ;
        end
    end
    
    x = sum(recorddata(:, 2:5), 2) ;
    trend = medfilt1(x, 1000*1.2) ;
    trend = smooth(trend, 1000*2, 'loess') ;
    x = x-trend ;
    R = HRCFTG(x, 1000) ;
    L = quantile(diff(R), 0.25) ;
    
    for channelNO = 1: 4
        
        x = recorddata(:, channelNO+1) ;
        trend = medfilt1(x, 1000*2) ;
        trend = smooth(trend, 1000*3, 'loess') ;
        x = x-trend ;
        
        
        
        
        for jj = 1: NO
            
            Qidx = ceil(rand(10,1) * (length(R)-2)) + 1 ;
            % generate one ECG pattern
            z = x(R(Qidx(1))-ceil(L*0.2)+1: R(Qidx(1))+ceil(L*0.6)) ;
            for qq = 2:10
                z = z + x(R(Qidx(qq))-ceil(L*0.2)+1: R(Qidx(qq))+ceil(L*0.6)) ;
            end
            
            
            
            % remove the linear trend
            z = z + (z(1)-z(end)) * [0:length(z)-1]' ./ (length(z)-1) ;
            z = z - mean(z) ;
            
            
            
            % upsample to 512Hz
            z0 = resample(z, fs, length(z)) ;
            z0 = z0 ./ norm(z0) ;
            zhat0 = fft(z0) ;
            
            
            zhat = zhat0 ;
            
            % randomly perturb the shape
            %if jj > 1
            %    A = randn(100,1)/10 + 1 ;
            %    phi = (rand(100,1)-0.5) /5 ;
            %    J = exp(i*2*pi*phi) ;
            %    zhat(2:101) = zhat(2:101) .* A .* J ;
            %    zhat(512:-1:413) = zhat(512:-1:413) .* A .* conj(J) ;
            %end
            
            
            % remove the fundamental component
            if REMOVEfund
                zhat(1) = 0 ; zhat(2) = 0 ; zhat(end) = 0 ;
            end
            z = ifft(zhat) ;
            
            % original signal
            xx0 = repmat(z0, T, 1) ;
            xhat0 = abs(fft(xx0)) .^ 2 ;
            STRENGTH(IDX, 6) = sum(xhat0(idx1+1)) ./ sum(xhat0(2:end/2)) ;
            
            xx = repmat(z, T, 1) ;
            
            % abs
            x1 = abs(xx) ;
            xhat1 = abs(fft(x1)) .^ 2 ;
            STRENGTH(IDX, 1) = sum(xhat1(idx1+1)) ./ sum(xhat1(2:end/2)) ;
            
            % RELU
            x2 = xx ; x2(find(x2<0)) = 0 ;
            xhat2 = abs(fft(x2)) .^ 2 ;
            STRENGTH(IDX, 2) = sum(xhat2(idx1+1)) ./ sum(xhat2(2:end/2)) ;
            
            %
            x3 = 0.8 * xx ./ max(abs(xx)) ;
            x3 = 1 ./ (1 - abs(x3)) ;
            xhat3 = abs(fft(x3)) .^ 2 ;
            STRENGTH(IDX, 3) = sum(xhat3(idx1+1)) ./ sum(xhat3(2:end/2)) ;
            
            %
            x4 = 0.9 * xx ./ max(abs(xx)) ;
            x4 = 1 ./ (1 - abs(x4)) ;
            xhat4 = abs(fft(x4)) .^ 2 ;
            STRENGTH(IDX, 4) = sum(xhat4(idx1+1)) ./ sum(xhat4(2:end/2)) ;

            %
            x5 = 0.95 * xx ./ max(abs(xx)) ;
            x5 = 1 ./ (1 - abs(x5)) ;
            xhat5 = abs(fft(x5)) .^ 2 ;
            STRENGTH(IDX, 5) = sum(xhat5(idx1+1)) ./ sum(xhat5(2:end/2)) ;
            
            IDX = IDX + 1 ;
            
        end
    end
end

disp(IDX)




%%
idxQ = find(~isnan(sum(STRENGTH,2))) ;
ITEM = {'abs', 'RELU', '\epsilon=0.2', '\epsilon=0.1', '\epsilon=0.05'} ;

tmp = log(STRENGTH(idxQ, 1:4)) ;
mmm = floor(min(tmp(:))) ;


%%
if REMOVEfund
    h0 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]) ;
    
    figure(h0) ;
    subplot(4,5,1) ;
    plot([1:length(z)]/fs, z0, 'k', 'linewidth', 2) ; axis tight ;
    set(gca,'fontsize', 16) ; xlabel('Time (s)') ; ylabel('s_{75,4}^{(0)} (a.u.)')
    subplot(4,5,3) ;
    plot([1:length(z)]/fs, z, 'k', 'linewidth', 2) ; axis tight ;
    set(gca,'fontsize', 16) ; xlabel('Time (s)') ; ylabel('s_{75,4} (a.u.)')
    subplot(4,5,2) ;
    bar(fs*[1:length(z)/2]/length(z), abs(zhat0(2:end/2+1)).^2/fs, 'k') ; axis([0 20 -inf inf]) ;
    set(gca,'fontsize', 16) ; xlabel('Frequency (Hz)') ; ylabel('PS of s_{75,4}^{(0)} (a.u.)') ;
    subplot(4,5,4) ;
    bar(fs*[1:length(z)/2]/length(z), abs(zhat(2:end/2+1)).^2/fs, 'k') ; axis([0 20 -inf inf]) ;
    set(gca,'fontsize', 16) ; xlabel('Frequency (Hz)') ; ylabel('PS of s_{75,4} (a.u.)') ;
    
    
    x1 = abs(z) ;
    xhat1 = abs(fft(x1)) .^ 2 ;
    
    x2 = z ; x2(find(x2<0)) = 0 ;
    xhat2 = abs(fft(x2)) .^ 2 ;
    
    x3 = 0.8 * z ./ max(abs(z)) ;
    x3 = 1 ./ (1 - abs(x3)) ;
    xhat3 = abs(fft(x3)) .^ 2 ;
    
    x4 = 0.9 * z ./ max(abs(z)) ;
    x4 = 1 ./ (1 - abs(x4)) ;
    xhat4 = abs(fft(x4)) .^ 2 ;
    
    x5 = 0.95 * z ./ max(abs(z)) ;
    x5 = 1 ./ (1 - abs(x5)) ;
    xhat5 = abs(fft(x5)) .^ 2 ;
    
    subplot(4,5,6) ;
    plot([1:length(z)]/fs, x1, 'b', 'linewidth', 2) ; axis tight ;
    set(gca,'fontsize', 16) ; xlabel('Time (s)') ; ylabel('g_{75,4}^{(1)} (a.u.)')
    subplot(4,5,7) ;
    plot([1:length(z)]/fs, x2, 'b', 'linewidth', 2) ; axis tight ;
    set(gca,'fontsize', 16) ; xlabel('Time (s)') ; ylabel('g_{75,4}^{(2)} (a.u.)')
    subplot(4,5,8) ;
    plot([1:length(z)]/fs, x3, 'b', 'linewidth', 2) ; axis tight ;
    set(gca,'fontsize', 16) ; xlabel('Time (s)') ; ylabel('g_{75,4}^{(3)} (a.u.)')
    subplot(4,5,9) ;
    plot([1:length(z)]/fs, x4, 'b', 'linewidth', 2) ; axis tight ;
    set(gca,'fontsize', 16) ; xlabel('Time (s)') ; ylabel('g_{75,4}^{(4)} (a.u.)')
    subplot(4,5,10) ;
    plot([1:length(z)]/fs, x5, 'b', 'linewidth', 2) ; axis tight ;
    set(gca,'fontsize', 16) ; xlabel('Time (s)') ; ylabel('g_{75,4}^{(5)} (a.u.)')
    
    subplot(4,5,11) ;
    bar(fs*[1:length(x1)/2]/length(x1), abs(xhat1(2:end/2+1))/fs, 'b') ; axis([0 20 -inf inf]) ;
    set(gca,'fontsize', 16) ; xlabel('Frequency (Hz)') ; ylabel('PS of g_{75,4}^{(1)} (a.u.)') ;
    subplot(4,5,12) ;
    bar(fs*[1:length(x1)/2]/length(x1), abs(xhat2(2:end/2+1))/fs, 'b') ; axis([0 20 -inf inf]) ;
    set(gca,'fontsize', 16) ; xlabel('Frequency (Hz)') ; ylabel('PS of g_{75,4}^{(2)} (a.u.)') ;
    subplot(4,5,13) ;
    bar(fs*[1:length(x1)/2]/length(x1), abs(xhat3(2:end/2+1))/fs, 'b') ; axis([0 20 -inf inf]) ;
    set(gca,'fontsize', 16) ; xlabel('Frequency (Hz)') ; ylabel('PS of g_{75,4}^{(3)} (a.u.)') ;
    subplot(4,5,14) ;
    bar(fs*[1:length(x1)/2]/length(x1), abs(xhat4(2:end/2+1))/fs, 'b') ; axis([0 20 -inf inf]) ;
    set(gca,'fontsize', 16) ; xlabel('Frequency (Hz)') ; ylabel('PS of g_{75,4}^{(4)} (a.u.)') ;
    subplot(4,5,15) ;
    bar(fs*[1:length(x1)/2]/length(x1), abs(xhat5(2:end/2+1))/fs, 'b') ; axis([0 20 -inf inf]) ;
    set(gca,'fontsize', 16) ; xlabel('Frequency (Hz)') ; ylabel('PS of g_{75,4}^{(4)} (a.u.)') ;
    
    
    for jj = 1: 5
        subplot(4,5,15+jj) ;
        [a,b] = hist(log(STRENGTH(idxQ, jj)), 200) ;
        bar(b,a/sum(a), 'r')
        ylabel(ITEM{jj}) ; axis([-10 0 0 0.1]) ;
        xlabel('log(energy ratio)') ;
        set(gca,'fontsize', 16) ;
        disp([num2str(round(1000*median(STRENGTH(idxQ, jj)))/10) ' ' ...
            num2str(round(1000*mad(STRENGTH(idxQ, jj)))/10)]) ;
        %disp([num2str(round(1000*mean(STRENGTH(idxQ, jj)))/10) ' ' ...
        %    num2str(round(1000*std(STRENGTH(idxQ, jj)))/10)]) ;
    end
    
    
    export_fig(['Fig7simu'], '-transparent','-m3') ;
    
    
    
    
else
    % provide the ratio improvement. remember to comment out "remove the fundamental
    % component"
    h2 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)/4]) ;
    
    for jj = 1: 5
        subplot(1,5,jj) ;
        %plot(log(STRENGTH(idxQ, 5)), log(STRENGTH(idxQ, jj)./STRENGTH(idxQ, 5)), 'xk') ;
        histo2D([log(STRENGTH(idxQ, 6)) log(STRENGTH(idxQ, jj)./STRENGTH(idxQ, 6))],[-15 0],75,[-15 10],125, '', '', '') ;
        ylabel('log(improvement)') ;
        xlabel('Original energy ratio') ; axis([-15 0 -15 10]) ;
        %hold on; plot([-15 0], [0 0], 'r', 'linewidth',3) ;
        set(gca,'fontsize', 16) ;
        idx = find(STRENGTH(idxQ, 6) < STRENGTH(idxQ, jj)) ;
        title([num2str(round(1000*length(idx)/length(idxQ))/10) '%']) ;
    end
    colormap(1-gray)
    export_fig(['Fig8simu'], '-transparent','-m3') ;
    
    
    h3 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)/4]) ;
    
    plot(STRENGTH(:, 5), 'k')
    xlabel('index') ;
    ylabel('energy ratio of the fundamental component') ;
    set(gca,'fontsize', 16) ;
    ylabel('    Energy ratio of the\newlinefundamental component') ;
    export_fig(['Fig8simu1'], '-transparent','-m3') ;
    
end



pause(1)
